<div class="codigo-java">
<pre>
b = c;
</pre>
</div>
<p>Atribua o valor da variável c á variável b. Os bits da variável c serão copiados, e essa nova cópia será inserida na variável b. As duas variáveis contêm valores idênticos</p>

<p>Tanto b quanto c referenciam o mesmo objeto. o objeto 1 será abandonado e estará qualificado para a Coleta de Lixo (GC, Garbage Collection).</p>

<p>Referências ativas: 2</p>
<p>Objetos alcançáveis: 1</p>
<p>Objetos abandonados: 1</p>

<p>O primeiro objeto que b referenciava, o objeto 1, não têm mais referências, se tornou inalcançável.</p>

<br>