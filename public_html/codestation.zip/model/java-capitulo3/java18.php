<div class="codigo-java">
<pre>
c = null;
</pre>
</div>

<p>Atribua o valor null à variável c. Isso a tornará uma referência nula, o que significa que ela não está referenciando nada. </p>
<p>Mas continua a ser uma variável de referência e outro objeto Book pode ser atribuído a ela.</p>

<p>O objeto 2 ainda tem uma referência ativa (b) e, enquanto a tiver, não estará qualificado GC.</p>

<p>Referências ativas: 1</p>
<p>Referências nulas: 1</p>
<p>Objetos alcançáveis: 1</p>
<p>Objetos abandonados: 1</p>

<br>