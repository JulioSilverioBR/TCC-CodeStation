
<h2>Ímãs com código</h2>
<h3>Exercício</h3>
<p>Um programa java funcional está todo misturado sobre a porta da geladeira. Você conseguiria reorganizar os trechos de código para criar um programa Java funcional que produzisse a saída listada abaixo? Algumas das chaves caíram no chão e são muitos pequenas para que as recuperemos, portanto, fique a vontade para adicionar quantas delas precisar!</p>

<div class="codigo-java">
<pre>
if (x == 1) {

System.out.println("d");

x = x - 1;

}


if (x == 2) {

System.out.println("b c");

}


class Shuffle {

public static void main (String[] args) {


if (x > 2) {

System.out.println("a");

}


int x = 3;


x = x - 1;

System.out.println("-");


while (x > 0) {


Saída do compilador
a-b c-d
</pre>
</div>