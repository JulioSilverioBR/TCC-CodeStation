
<h2>Seja o compilador</h2>
<h3>Exercício</h3>
<p>Cada um dos arquivos Java dessa página representa um arquivo-fonte completo. Sua tarefa é personificar o compilador e determinar se cada um deles pode ser compilado. Se não puderem ser compilador, como você os corrigiria?</p>


<p>A)</p>

<div class="codigo-java">
<pre>
class Exercicio1

public static void main (String[] args) {

int x = 1;

while (x < 10) {

if (x > 3){

System.out.println("x");

}

}

}

}
</pre>
</div>
<p>B)</p>

<div class="codigo-java">
<pre>
public static void main (String[] args) {

int x = 5;

while (x > 1) {

x = x - 1;

if (x < 3) {

System.out.println("x");

}

}

}
</pre>
</div>

<p>C)</p>
<div class="codigo-java">
<pre>
class Exercicio1c

int x = 5;

while (x > 1) {

if (x < 3) {

System.out.pritln("x");

}

}

}

</pre>
</div>