<h2>Um histórico bem resumido do Java</h2>
<br>
<h3>Java 1.02</h3>
<h4>250 classes</h4>
<h4>Lenta.</h4>
<p>Nome e logotipo interessantes. Divertido de usar. Muitos erros. Os applets são o destaque.</p>

<h3>Java 1.1</h3>
<h4>500 classes</h4>
<h4>Um pouco mais rápida.</h4>
<p>Mais recursos, mais amigável. Começando a se tornar muito popular. Código de GUI mais adequado.</p>

<h3>Java 2 (versões 1.2 -1.4)</h3>
<h4>2.300 clases</h4>
<h4>Muito mais rápida.</h4>
<p>Pode (em algumas situações) ser executada em velocidades condizentes. Profissional, poderosa. Vem em três versões: Micro Edition (J2ME), Standart Edition (J2SE) e Enterprise Edition (J2EE). Torna-se a linguagem preferida para novos aplicativos empresariais (principalmente os baseados na Web) e móveis.</p>

<h3>Java 5.0 (versões 1.5 e posteriores)</h3>
<h4>3.500</h4>
<h4>Mais recursos, mais fácil de desenvolver</h4>
<p>Além de adicionar mais de mil classes complementares, a Java 5.0 (conhecida como "Tiger) acrescentou alterações significativas à própria linguagem, tornando-a mais fácil (pelo menos em teoria) para os novos programadores e fornecendo novos recursos que eram populares em outras linguagens.</p>
