<h2>Aponte seu lápis</h2>
<p>Veja como é fácil escrever código Java
Tente adivinhar o que cada linha de código está fazendo... 
As respostas estão aqui</p>

<div class="codigo-java">
<pre>
int tamanho = 27;

String nome = "Code Station";

Codigo meuCodigo = new Codigo(nome, Code Station);

x = Code Station - 5;

if (x < 15 ) meuCodigo.executa(8);

while (x > 3) { 
        meuCodigo.compila();

}
int[] numLista = {2,4,6,8};

System.out.print("Olá Mundo!");

System.out.print("Meu nome é:" + nome);

String num = "8";

int z = Integer.parseInt(num);

try { 
        leiaArquivo("meuArquivo.txt);
}

catch (ArquivoNaoEncontradoExcecao ex){ 
System.out.print("Arquivo Não Encontrado"); 
}
</pre>
</div>
<h2>Ainda não é preciso se preocupar em entender tudo isso!</h2>

<p>Tudo que se encontra aqui é explicado com maiores detalhes neste curso, grande parte nos primeiros capítulos. Se o Java lembra uma linguagem que você usou no passado, alguns desses itens parecerão simples. Caso contrário, não se preocupe com isso. Chegaremos lá…</p>