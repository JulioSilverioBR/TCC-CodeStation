
<h3>Qual é a diferença entre uma classe e um objeto? </h3>
<p>Uma classe não é um objeto.
(Mas é usada para construí-los)
Uma classe é o projeto de um objeto. Ela informa à máquina virtual como criar um objeto desse tipo específico. Cada objeto criado a partir dessa classe será seus próprios valores para as variáveis de instância da classe. Por exemplo, você pode usar a classe Button para criar vários botões diferentes, e cada botão diferentes, e cada botão poderá ter sua própria cor, tamanho, forma, rótulo e assim por diante.
</p>