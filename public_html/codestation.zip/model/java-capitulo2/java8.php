
<h2>De volta à baia de Larry</h2>
<p>Ele achou que seria melhor adicionar os pontos de rotação como argumentos do procedimento de rotação. Grande parte do código foi afetada. Teste, compilação, todo o trabalho teve que ser feito novamente. O que funcionava deixou de funcionar.</p>
<div class="codigo-java">
<pre>
        rotate(shapeNum xPt, yPt) {
        // se a forma não for uma ameba
            // calcule o ponto central
            // baseado em um retângulo,
            // e, em seguida, gire
        // ou
            // use xPt e yPt como
            // o deslocamento do ponto de rotação
            // e, em seguida, gire
        }
</pre>
</div>
<p>Não pareceu ser uma grande idéia, mas ele se sentia desconfortável em alterar código já testado. Entre todas as pessoas, ele sabia que, independentemente do que o gerente de projetos dissesse, as especificações sempre seriam alteradas.</p>
