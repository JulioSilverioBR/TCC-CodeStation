
<h2>Na baia de Larry</h2>
<p>Como já tinha feito milhares de vezes, Larry começou a escrever seus Procedimentos Importantes. Ele criou rotate e playSound sem demora.</p>
<div class="codigo-java">
<pre>
    rotate(shapeNum) {
        // faz a forma girar em 360
    }
</pre>
</div>
<br>
<div class="codigo-java">
<pre>
    playSound(shapeNum) {
        // usa shapeNum para pesquisar
        // que som AIF reproduzir e executá-lo
    }
</div>
</pre>