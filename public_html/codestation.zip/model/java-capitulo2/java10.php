
<h2>Então, Brad o adepto da OO ganhou a cadeira, certo?</h2>
<p>Não tão rápido. Larry encontrou uma falha na abordagem de Brad. E, já que tinha certeza de que, se ganhasse a cadeira, também se daria bem com a Lucy da contabilidade, tinha que rever a situação</p>

<p>Larry: Você tem código duplicado! O procedimento de rotação aparece em todos os quatro itens Shape.</p>

<p>Brad: Trata-se de um método e não um procedimento. E essa são classes e não itens.</p>

<p>Larry: Não importa. É um projeto estúpido. Você tem que manter quatro "métodos" de rotação diferentes. Em que isso poderia ser bom?</p>

<p>Brad: Oh, acho que você não viu o projeto final. Deixe que eu lhe mostre como a herança da OO funciona, Larry.</p>
