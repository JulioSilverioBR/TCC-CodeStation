
<h2>Dica metacognitiva</h2>
<p>Se você empacou em um exercício, tente falar sobre ele em voz alta. Falar (e ouvir) ativará uma parte diferente de seu cérebro. Embora isso funcione melhor quando temos outra pessoa com quem discutir, também funciona com animais de estimação. Foi assim que nosso cão aprendeu polimorfismo</p>
