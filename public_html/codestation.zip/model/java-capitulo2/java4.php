
<h2>Larry achou que tinha conseguido. Podia quase sentir as rodas de aço da Aeron rolando embaixo de seu...</h2>
<p>Mas espere! Houve uma alteração nas especificações.</p>

<p>Certo, tecnicamente você venceu, Larry", disse o Gerente, "mas temos que adicionar apenas mais um pequeno item ao programa. Não será problema para programadores Avançados como vocês dois."</p>

<p>"Se eu ganhasse uma moeda sempre que ouvisse isso", pensou Larry, sabendo que alterações nas especificações sem problemas era ilusão. "E mesmo assim Brand parece estranhamente tranquilo. O que estará acontecendo?" Larry continuou mantendo sua crença de que fazer da maneira orientada a objetos, embora avançado, era lento. E que, se alguém quisesse fazê-lo mudar de idéia, teria que fazer isso à força.</p>

<p>O que foi adicionado às especificações</p>
<p>Haverá o formato de uma ameba na tela, junto com as outras formas. Quando o usuário clicar na ameba, ela girará como as outras formas e reproduzirá um arquivo de som .hif</p>
