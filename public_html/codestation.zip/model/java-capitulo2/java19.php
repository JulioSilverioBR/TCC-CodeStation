
<h2>Aponte seu lápis</h2>

<pre>
<div class="codigo-java">
Movie
title
genre
rating
playlt(  )
</div>
</pre>

<p>
A classe MovieTestDrive cria objetos (instância) da classe
Movie e usa o operador ponto(.) para configurar as variáveis de
instância com um valor específico.
Ela também referência (chama) um método em um dos objetos.
Preencha a figura à direita com os valores que os três objetos apresentam no fim de main().
</p>

<pre>
<div class="codigo-java">
Objeto 1  
title
genre
rating

Objeto 2
title 
genre
rating

Objeto 3
title
genre
rating
</div>
</pre>