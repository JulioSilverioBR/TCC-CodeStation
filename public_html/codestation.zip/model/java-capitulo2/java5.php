
<h2>De volta à baia de Larry</h2>
<p>O procedimento de rotação ainda funcionaria; o código usava uma tabela de pesquisa para comprar o argumento shapeNum com a figura de uma forma real. Mas playSound teria que mudar. E o que diabos é um arquivo .hif?</p>
<div class="codigo-java">
<pre>
    playSound(shapeNum) {
        // se a forma não for uma ameba, 
            // use shapeNum para pesquisar que
            // som AIF reproduzir e execute-o
        // ou
            // reproduza o som .hif da ameba
    }
</pre>
</div>
<p>Não pareceu ser uma grande idéia, mas ele sentia desconfortável em alterar código já estado. Entre todas as pessoas, ele sabia que, independemente do que o gerente de projetos dissesse, as especificações sempre seriam alteradas.</p>
