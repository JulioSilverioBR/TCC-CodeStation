    <footer id="comentario">
      <p><div>Todos os direitos reservados ® <a style="text-decoration: underline;" title="Politica de privacidade" href="politicadeprivacidade">Política de Privacidade</a></div></p>
    </footer>
