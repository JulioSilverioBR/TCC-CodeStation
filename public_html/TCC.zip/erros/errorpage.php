<html>
<?php include '../model/header.php';?>
        <title><?php echo $titulo; ?> - Class não encontrada</title>
    <body style="text-align:center">
        <h1>ERROR 404</h1>
         <h1>Class Not found</h1>
         <img src="../erros/dinossauro.png"><br>
         <a href="../pagina">Voltar para o pacote principal</a>
    </body>
</html>