<head>
    <meta name="theme-color" content="#3d3d55">
    <?php $titulo = "Code Station";?>
    

        <script type="text/javascript" src="../js/jquery.js"></script>
        
        <link rel="icon" href="icone.png"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        
       <script defer src="https://use.fontawesome.com/releases/v5.6.3/js/all.js" integrity="sha384-EIHISlAOj4zgYieurP0SdoiBYfGJKkgWedPHH4jCzpCXLmzVsw1ouK59MuUtP4a1" crossorigin="anonymous"></script>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6361856937114237",
    enable_page_level_ads: true
  });
</script>

       
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
         
        <style>
        <?php include 'pagina.css'; ?>
        </style>
        
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
   window.onload = () => {
    let el = document.querySelector('[alt="www.000webhost.com"]').parentNode.parentNode;
    el.parentNode.removeChild(el);
}
</script>

        
        
        <style>
        <?php include 'style.css'; ?>
        
        </style>
        
        <style>
        <?php include 'botao.css'; ?>
        </style>
    </head>
    
    
<?php @include 'model/loading.php'?>