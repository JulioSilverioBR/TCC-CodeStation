	
<h2>Tipos primitivos</h2>
<br>
<div class="codigo-java">
<pre>
byte - 8bits 
curto - 16bits
int - 32bits
long - 63bits 
float - 32 bits
double - 64 bits 
</pre>
</div>
<br>