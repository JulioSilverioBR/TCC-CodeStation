
<p>1. Declare uma variável de matriz int. Uma variável de matriz é o controle remoto de um objeto de matriz.
int [ ] nums;</p>

<p>2. Crie uma nova matriz int de tamanho 7 e a atribua à variável int[ ] nums já declarada
nums = new int[7];</p>

<p>3. Forneça para cada elemento da matriz um valor int.
Lembra-se de que os elementos de uma matriz int são apenas variáveis int.</p>
<br>
<pre>
nums[0] = 6;<br>
nums[1] = 19;<br>
nums[2] = 44;<br>
nums[3] = 42;<br>
nums[4] = 10;<br>
nums[5] = 20;<br>
nums[6] = 1;<br>
</pre>
<br>