<div class="codigo-java">
<pre>
Book d = c;
</pre>
</div>
<p>Declare uma nova declare de referência book. Em vez de criar um terceiro objeto Book, atribua o valor da variável c à variável d. Mas o que isso significa? É como dizer "pegue os bits de c, faça uma cópia deles e insira essa cópia em d"</p>

<p>Tanto c quanto b referências o mesmo objeto. As variáveis c e d contém duas cópias diferentes com o mesmo valor. Dois controles remotos programados para uma TV.</p>

<p>Referências: 3</p>
<p>Objetos: 2</p>
<br>