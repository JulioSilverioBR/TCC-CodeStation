
<h2> Crie uma matriz de objetos Dog </h2> 
<h3> 1. Declare uma variável de matriz Dog </h3>
<div class="codigo-java">
<pre>
Dog[] pets;
</pre>
</div>
<h3> 2. Crie uma nova matriz Dog com tamanho igual a 7 e a atribua à variável Dog[] pets já declarada </h3>
<div class="codigo-java">
<pre>
pets = new Dog[7];
</pre>
</div>
<p>Objetos Dog! Temos uma matriz de referências Dog, mas nenhum objeto Dog real</p>

<h3> 3. Crie novos objetos Dog e atribua-os aos elementos da matriz. Lembre-se de que os elementos de uma matriz Dog 
são apenas variáveis de referência Dog. </h3>
<br>
<p>Ainda precisamos de objetos Dog!</p>
<div class="codigo-java">
<pre>
pets[0] = new Dog;
pets[1] = new Dog;
</pre>
</div>
<br>