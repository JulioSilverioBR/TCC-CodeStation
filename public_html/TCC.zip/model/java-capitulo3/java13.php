
<h2> A vida na pilha de lixo coletável </h2>
<br>
<div class="codigo-java">
<pre>
 Book b = new Book();
 Book c = new Book();
 </pre>
</div>
 <p>Declare duas variáveis de referência Book. Crie dois novos objetos Book. Atribui os objetos Book ás variáveis de referências.</p>

<p>Agora os dois objetos Book estão residindo na pilha.</p>

<p>Referências: 2</p>
<p>Objetos: 2</p>
<br>