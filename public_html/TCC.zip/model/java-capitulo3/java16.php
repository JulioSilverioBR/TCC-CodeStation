
<h2> Vida e morte na pilha </h2>
<br>

<div class="codigo-java">
<pre>
Book b = new Book( );
Book c = new Book( );
</pre>
</div>

<p>Declare duas variáveis de referência. Crie dois novos objetos Book. Atribua os objetos Book ás variáveis de referência.</p>

<p>Agora os dois objetos Book estão residindo na pilha</p>

<p>Referências ativas: 2</p>
<p>Objetos alcançáveis: 2</p>
<br>