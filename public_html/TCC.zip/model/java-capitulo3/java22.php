
<h2> Aponte seu lápis </h2>
<p>Qual é o valor atual de pets[2]?</p>
<p>Que código faria pets[3] referências um dos dois objetos Dog existentes?</p>
<br>