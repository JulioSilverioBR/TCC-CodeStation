<div class="codigo-java">
<pre>
c = b;
</pre>
</div>
<p>Atribua o valor da variável da variável b à variável c. Agora você já sabe o que isso significa. Os bits da variável b serão copiados e essa nova cópia será inserida na variável c.</p>

<p>Tanto b quanto c referências o mesmo objeto</p>

<p>Referências: 3</p>
<p>Objetos: 2</p>
<br>
