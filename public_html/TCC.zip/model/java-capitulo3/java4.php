<h2>Declarações primitivas com atribuições: </h2>
<br>
<div class="codigo-java">
<pre>
int x;
x = 234;
bye b = 89;
boolean isFun = true;
double d = 3256.98;
char c = 'f';
int z = x;
boolean isPunkRock;
isPunkRock = false;
boolean powerOn;
powerOn = isFun;
long big = 3456789;
float f = 32.5f;
</pre>
</div>
<p>Observe o 'f'. É preciso inseri-lo em um tipo considera tudo que encontra com um ponto flutuante como um tipo double, a menos que 'f' seja usado. </p>