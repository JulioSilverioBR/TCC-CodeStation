
<h2>System.out.PRINT versus System.out.printLN</h2>
<p>Se você prestou atenção (é claro que prestou), deve ter notado que nos alternamos entre print e println.</p>

</p>Você entendeu a diferença?</p>

<p>System.out.println insira uma nova linha (pense em um println como printnewline), enquanto System.out.println continua exibindo na mesma linha. Se você quiser que cada coisa que exibir seja em sua própria linha, use println. Se quiser que tudo fique junto em uma linha, use print.</p>
