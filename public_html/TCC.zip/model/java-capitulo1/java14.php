
<h2>Lembrete rápido</h2>
<p>- As instruções terminam em ponto-e-vírgula;</p>

<p>- Os blocos de código são definidos por um par de chaves { }</p>

<p>- Declare uma variável int com um nome e um tipo: int x;</p>

<p>- O operador de atribuição é um sinal de igualdade =</p>

<p>- O operador de igual a são dois sinais de igualdade ==</p>

<p>- O loop while executará tudo que estiver dentro de seu bloco (definido por chaves), contanto que o teste condicional seja verdadeiro.</p>

<p>- Se o teste condicional for falso, o bloco de código do loop while não será executado, e o processamento passará para baixo até o código imediatamente posterior ao bloco do loop.</p>

<p>- Coloque um teste booleano entre parênteses: (while x == 4) { }</p>
