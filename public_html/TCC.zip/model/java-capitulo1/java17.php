
<h2>Aponte seu lápis</h2>
<p>Dada a saída:</p>
<p>DooBeeDooBeeDo</p>

<p>Preencha as lacunas do código:</p>
<div class="codigo-java">
<pre>
public class DooBee {

 public static main void(String[] args) {

  int x = 1;

  while (x < ) {

   System.out.
    ("Doo");

   System.out.
    ("Boo");

   x = x + 1;

  }

  if (x == ) {

   System.out.println("Do");

  }
</pre>
</div>