
<h2>Larry acabou alguns minutos na frente de Brad.</h2>
<p>(Ah! Tanto barulho por aquela besteira de OO.) Mas o sorriso de Larry desapareceu quando o Gerente de Projetos Muito Chato disse( com esse tom de desapontamento): "Oh, não, não é assim que a ameba deve girar...!"</p>

<p>Os dois programadores acabaram escrevendo seu código de rotação dessa forma:</p>

<p>1: determine o retângulo que circula a forma</p>

<p>2: calcule o centro desse retângulo e gire a forma ao redor desse ponto.</p>

<p>Mas a forma de ameba devia girar ao redor de um ponto em uma extremidade, como um ponteiro de relógio.</p>

<p>"Estou frito" pensou Larry, visualizando um Wonderbred chamuscado. "Porém, hmmm. Eu poderia apenas adicionar outra instrução if/else ao procedimento de rotação e, em seguida, embutir o código do ponto de rotação da ameba. Provavelmente isso não atrapalhará nada." Mas uma voz longínqua em sua mente dizia: "É um grande erro. Você acha honestamente que as especificações não mudarão novamente?"</p>
