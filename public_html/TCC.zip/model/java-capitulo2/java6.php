
<h2>Usando o laptop de Brad na praia</h2>
<p>Brad sorriu, tomou um gole de sua marguerita e criou uma nova classe. Às vezes o que ele mais adorava na OO era não ser preciso mexer em um código que já tivesse sido testado e distribuído. "Flexibilidade, extensibilidade..." ele pensou, refletindo sobre os benefícios da OO.</p>

<p>Ameba</p>
<div class="codigo-java">
<pre>
    rotate(){
        // código para girar a ameba
    }
    
    playSound() {
        // código para reproduzir o novo
        // arquivo .hif de uma ameba
    }
</pre>
</div>