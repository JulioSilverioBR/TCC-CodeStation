
<h2>No laptop de Brad dentro do restaurante</h2>
<p>Brad criou uma classe para cada uma das três formas</p>

<p>Square</p>
<div class="codigo-java">
<pre>
    rotate(){
        // código para girar um quadrado
    }
    
    playSound() {
        // código para reproduzir o arquivo AIF
        // de um quadrado
    }
</pre>
</div>
<p>Circle</p>
<div class="codigo-java">
<pre>
    rotate(){
        // código para girar um circulo
    }
    
    playSound() {
        // código para reproduzir o arquivo AIF
        // de um circulo
    }
</pre>
</div>
<p>Triangle</p>
<div class="codigo-java">
<pre>
    rotate(){
        // código para girar um triângulo
    }
    
    playSound() {
        // código para reproduzir o arquivo AIF
        // de um triângulo
    }	
</pre>
</div>
