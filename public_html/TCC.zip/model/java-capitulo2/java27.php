<h2>
 Quem sou eu?
</h2>

<p>   
Um grupo de componentes Java, vestido a rigor, está participando do jogo, "Quem sou eu?" Em uma festa. 
Eles lhe darão uma pista e você tentará adivinhar quem são baseados no que disserem.
Se por caso disseram algo que possa ser verdadeiro para mais de um deles, selecione todos aos quais a frase possa ser aplicada.
Preencha as linhas em branco próximas a frase com os nomes de um ou mais candidatos.
A primeira é por nossa conta.
</p>

<h2>Candidatos desta noite: Classe Método Objeto Variavel de instância </h2>
<p>
Sou compilado em um arquivo .java: Classe<br>
Os valores da minha variável de instância podem ser diferentes do meu colega: <br>
Comporto-me como um modelo:<br>
Gosto de fazer coisas:<br>
Posso ter muitos métodos:<br>
Represento o 'estado':<br>
Odeio comportamentos:<br>
Estou situado nos objetos:<br>
Vivo no heap:<br>
Costuma criar instâncias de objeto:<br>
Meu estado pode se alterar:<br>
Declaro métodos:<br>
Posso mandar no tempo de execução:<br>
</p>