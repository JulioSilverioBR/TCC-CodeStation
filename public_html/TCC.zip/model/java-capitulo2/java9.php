
<h2>Usando o laptop de Brand em sua espreguiçadeira no Festival de Bluegrass de Telluride</h2>
<p>Sem perder nada, Brad modificou o método de rotação, mas só na classe Amoeba. Ele não tocou no código funcionar já testado e compilado das outras partes do programa. Para fornecer à classe Amoeba um ponto rotação, ele adiciona um atributo que todos os objetos Amoeba teriam. Ele modificou, testou e distribuiu (como tecnologia sem fio) o programa revisto apenas durante o show de Bela Fleck.</p>
<div class="codigo-java">
<pre>
        int x point;
        int y point;
        rotate() {
            // código para girar a ameba
            // usando os pontos x e y
        }
        
        playSound() {
            // código para reproduzir o novo
            // arquivo .hif de uma ameba
        }
</pre>
</div>