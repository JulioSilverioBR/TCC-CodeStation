var openLoginRight = document.querySelector('.h1','h2');
var loginWrapper = document.querySelector('.login-wrapper');
openLoginRight.addEventListener('click', function(){
  loginWrapper.classList.toggle('open'); 
});