 
<div class="hero" id="top">
        <div class="header hero-image fixeed"></div>
      <h1 style="z-index:1200;font-weight:400"></h1>
      </div>